STREET HOOPS 2D
아이패드 Safari에서 가로 화면으로 여는 것을 추천합니다.
왼쪽 조이스틱 이동, 오른쪽 버튼으로 슛/돌파/크로스.
WASD 또는 방향키 이동, Space 슛.
GitHub Pages에 배포하려면 index.html을 저장소 최상위에 업로드하세요.
